#!/usr/bin/env python3

__version__ = "0.1"

if __name__ == "__main__":
    # at least the CLI program name: (CLI) execution
    print(__version__)
